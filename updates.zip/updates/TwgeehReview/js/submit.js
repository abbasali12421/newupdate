function clickme(){
    document.getElementById("clickme").click();
}

var hide  = false;
function Hide(){
    var select = document.getElementsByClassName("select")[0];
   
    if (!hide) {
       select.setAttribute("disabled","");
       select.setAttribute("name","");
      
    
        hide = true;
    } else {
        select.removeAttribute("disabled");
        select.setAttribute("name","city");

        hide = false;
    }
    
}
var OpenMenuButton = document.getElementById("menuOpen");
var open = false;
function exec(){
    let documenter = document.getElementsByClassName("menu")[0];
    if(open == false){
        documenter.style.height = "350px";
        documenter.style.padding = "15px 15px";
       open = true;
      }else{
          documenter.style.height = "0px";
          documenter.style.padding = "0";
          open = false;
  
      }
}
OpenMenuButton.addEventListener("click",exec)
function blurMenu(){
    let documenter = document.getElementsByClassName("menu")[0];
    documenter.style.height = "0px";
    documenter.style.padding = "0";
    open = false;
}



