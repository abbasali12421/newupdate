<?php
// Include the config.php file to establish a connection to the database
require_once 'config.php';
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet" />
  <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap" rel="stylesheet" />
  <link href="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/7.3.2/mdb.min.css" rel="stylesheet" />
  <link rel="stylesheet" href="style/blog.css">
  <title>Blog</title>
  <style>
    .img{
      object-fit: cover;
      object-position: center;
    }

  /*add to blog.html head*/
  </style>
</head>

<body>

  <!-- Navbar -->
  <nav class="navbar navbar-expand-lg bg-light navbar-light">
    <!-- Container wrapper -->
    <div class="container-fluid">

      <!-- Navbar brand -->
      <a class="navbar-brand" href="#"><i class="fas fa-paperclip mx-3"></i> Blog</a>

      <!-- Toggle button -->
      <button class="navbar-toggler" data-mdb-collapse-init type="button" data-mdb-toggle="collapse"
        data-mdb-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
        aria-label="Toggle navigation">
        <i class="fas fa-bars"></i>
      </button>

      <!-- Collapsible wrapper -->
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav me-auto mb-2 mb-lg-0">

        </ul>

        <!-- Icons -->
        <ul class="navbar-nav d-flex flex-row me-1">
          <li class="nav-item me-3 me-lg-0">
            <a class="nav-link" href="index.php"><i class="fas fa-home mx-3"></i> <span>Home</span></a>
          </li>
          <li class="nav-item me-3 me-lg-0">
            <a class="nav-link" href="https://t.me/edutawjeeh"><i class="fab fa-telegram mx-3"></i> <span>Join</span></a>
          </li>
          <li class="nav-item me-3 me-lg-0">
            <a class="nav-link" href="#"><i class="fa-solid fa-right-from-bracket mx-3"></i> <span>Logout</span></a>
          </li>
        </ul>

        <!-- Search -->
        <form class="w-auto">
          <input type="search"  id="search-input" class="form-control" placeholder="Type query" aria-label="Search">
        </form>

      </div>
    </div>
    <!-- Container wrapper -->
  </nav>
  <!-- Navbar -->

  <div class="information-post m-3">
    <div class="post-container"  id="post-container">
      <?php
      // Create a query to retrieve the first 5 posts from the database
      $query = "SELECT * FROM posts ORDER BY date DESC LIMIT 5";

      // Execute the query and store the result in a variable
      $result = $conn->query($query);

      // Check if there are any posts in the database
      if ($result->num_rows > 0) {
          // Loop through each post and display the details
          while ($post = $result->fetch_assoc()) {
              ?>
              <div class="post">
                  <div class="image-post">
                      <img class="img" src="/admin/uploads/<?php echo $post['img']; ?>" />
                  </div>
                  <div class="post-details p-3 mx-3">
                      <h3><a class="nav-link" href="/blog/post.php?id=<?php echo $post['id'];?>"><?php echo $post['title']; ?></a></h3>
                      <div class="author">
                          <span><i class="fas fa-user"></i> admin</span>
                          <span><i class="fas fa-clock"></i> <?php echo $post['date']; ?></span>
                      </div>
                      <p class="post-description">
                            <?php echo substr($post['content'], 0, 50) . '...'; ?>
                      </p>
                  </div>
              </div>
              <?php
          }
      } else {
          echo "No posts found.";
      }
      ?>
      <button class="btn btn-primary" id="load-more">Show More</button>
    </div>

    <div class="posts-left-menu">
      <div class="card p-3">
        <div class="card-text fs-6 px-2" style="width: 150px;-radius: 5px;">Share With</div>
        <hr>
        <div class="social">
        <button data-mdb-ripple-init class="btn btn-primary" onclick="window.open('https://www.facebook.com/sharer/sharer.php?u=<?php echo 'https://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']; ?>', '_blank')">
        Facebook <i class="fab fa-facebook"></i>
</button>

<button data-mdb-ripple-init class="btn btn-danger" onclick="window.open('https://telegram.me/share/url?url=<?php echo 'https://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']; ?>', '_blank')">
    Telegram <i class="fab fa-telegram"></i>
</button>

<button data-mdb-ripple-init class="btn btn-dark" onclick="window.open('https://twitter.com/intent/tweet?url=YOUR_URL&text=Check this out! <?php echo 'https://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']; ?>', '_blank')">
    Twitter <i class="fab fa-twitter"></i>
</button>

<button data-mdb-ripple-init class="btn btn-success" onclick="window.open('https://api.whatsapp.com/send?text=Check this out! <?php echo 'https://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']; ?>', '_blank')">
    WhatsApp <i class="fab fa-whatsapp"></i>
</button>

        </div>
        <div class="pop mt-5">
          <div class="card-text fs-6 px-2" style="width: 150px;-radius: 5px;">Other Posts</div>
          <hr>
          <?php
          // Create a query to retrieve the latest post from the database
          $query = "SELECT * FROM posts ORDER BY date DESC LIMIT 1";

          // Execute the query and store the result in a variable
          $result = $conn->query($query);

          // Check if there is a latest post in the database
          if ($result->num_rows > 0) {
              // Loop through the latest post and display the details
              while ($post = $result->fetch_assoc()) {
                  ?>
                  <div class="post-left mb-5 mt-1">
                      <div class="img-left">
                          <img class="img-child-left" src="/admin/uploads/<?php echo $post['img']; ?>" />
                      </div>
                      <div class="posts">
                          <h5><a href="/blog/post.php?id=<?php echo $post['id'];?>" class="nav-link"><?php echo $post['title']; ?></a></h5>
                          <div>
                              <span><i class="fas fa-clock"></i> <?php echo $post['date']; ?></span>
                          </div>
                      </div>
                  </div>
                  <?php
              }
          } else {
              echo "No posts found.";
          }

          // Check if there are more than 5 posts
          $totalPosts = $conn->query("SELECT COUNT(*) FROM posts")->fetch_assoc()['COUNT(*)'];
          if ($totalPosts > 5) {
              ?>
              <?php
          }
          ?>
        </div>
        <div class="subscribe">
          <div class="card-text fs-6 px-2" style="width: 150 px;-radius: 5px;">Subscribe</div>
          <hr>
          <form>
              <input type="email" class="form-control" placeholder="Enter your email" aria-label="Email">
              <br><button class="btn btn-primary">Subscribe</button>
          </form>
        </div>
      </div>
    </div>
  </div>

  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/7.3.2/mdb.min.js"></script>
  <script src="script.js"></script>

</body>

</html>