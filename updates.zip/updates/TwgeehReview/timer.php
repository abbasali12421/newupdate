<!DOCTYPE html>
<html lang="ar">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css"
    integrity="sha512-Kc323vGBEqzTmouAECnVceyQqyqdsSiqLQISBL29aUW4U/M7pSPA/gEUZQqv1cwx4OnYxTxve5UMg5GT6L4JJg=="
    crossorigin="anonymous" referrerpolicy="no-referrer" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"
    integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A=="
    crossorigin="anonymous" referrerpolicy="no-referrer" />
  <link rel="stylesheet" href="style/style.css">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style/menu.css">
    <link rel="stylesheet" href="style/style.css">
    <title>عنوان الصفحة</title>
 <style>
 /* عداد الامتحانات الوزارية */
.container {
    display: flex;
    flex-direction: column;
    justify-content: center;  /* التوسيط العمودي */
    align-items: center;      /* التوسيط الأفقي */
    text-align: center;       /* توسيط النصوص */
    padding: 15px;
    background: #fff;
    border-radius: 20px;
    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
    width: 90%;
    max-width: 600px;
    margin: 0 auto;           /* تأكيد التوسيط على المحور الأفقي */
    margin-bottom: 20px;
}

.container:hover {
    transform: scale(1.05);
}

.section-title {
    font-size: 1.5rem;
    color: #333;
    margin: 15px 0;
    font-weight: bold;
    text-align: center;
    padding: 10px;
    background: #4CAF50;
    color: #fff;
    border-radius: 10px;
}

.timer {
    display: flex;
    justify-content: center;  /* التوسيط الأفقي للعناصر */
    gap: 15px;
    margin-bottom: 20px;
}

.time {
    background: #4CAF50;
    color: #fff;
    border-radius: 10px;
    padding: 10px;
    width: 90px;
    text-align: center;
    min-height: 100px;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    transition: background-color 0.3s;
}

.time:hover {
    background: #45a049;
}

.time span {
    font-size: 2.5rem;
    font-weight: bold;
    font-variant-numeric: tabular-nums;
    direction: ltr;
}

.time p {
    font-size: 1rem;
    margin-top: 5px;
    font-weight: normal;
}

.message p {
    font-size: 1.2rem;
    color: #333;
    font-weight: bold;
    padding: 10px;
    background: #e9ecef;
    border-radius: 10px;
    margin-top: 15px;
}


 </style>
</head>
<body>
    <header class="toolbar">
        <div class="navbar">
          <div class="logo">
    
            <h1 class="logo-title">Twajeeh Education</h1>
          </div>
          <div class="menu-mobile">
            <div class="menu-click">
              <button id="menuOpen"><i class="fas fa-bars"></i></button>
            </div>
          </div>
          <div class="items">
            <ul>
            <li><a href="blog.php" class="link">المدونة</a></li>
          <li><a href="" class="link">الارشيف</a></li>
          <li><a href="#" class="link">حول المنصة</a></li>
          <li><a href="timer.php" class="link">الوقت المتبقي للامتحانات الوزارية</a></li>
            </ul>
          </div>
          <div class="login">
            <a class="link" href="/page/login.php">login</a>
            <a href="/page/register.php"><button class="btn btn-primary">Sign up</button></a>
          </div>
        </div>
        <div class="menu">
          <ul class="menu-items">
          <li><a href="blog.php" class="link">المدونة</a></li>
          <li><a href="" class="link">الارشيف</a></li>
          <li><a href="#" class="link">حول المنصة</a></li>
          <li><a href="timer.php" class="link">الوقت المتبقي للامتحانات الوزارية</a></li>
          </ul>
          <button class="menu-btn-sign-up">Sign up</button>
          <button class="menu-btn-login">Login</button>
        </div>
    
      </header>
   <!-- عداد الامتحانات الوزارية -->
   <div class="container">
        <div class="section-title">الوقت المتبقي للامتحانات الوزارية للصف السادس الاعدادي</div>
        <div class="timer">
            <div class="time">
                <span id="days1">00</span>
                <p>أيام</p>
            </div>
            <div class="time">
                <span id="hours1">00</span>
                <p>ساعات</p>
            </div>
            <div class="time">
                <span id="minutes1">00</span>
                <p>دقائق</p>
            </div>
            <div class="time">
                <span id="seconds1">00</span>
                <p>ثواني</p>
            </div>
        </div>
        <div class="message">
            <p>الوقت المتبقي</p>
        </div>
    </div>

    <!-- عداد الثالث المتوسط -->
    <div class="container">
        <div class="section-title">الوقت المتبقي للامتحانات الوزارية للصف الثالث المتوسط</div>
        <div class="timer">
            <div class="time">
                <span id="days2">00</span>
                <p>أيام</p>
            </div>
            <div class="time">
                <span id="hours2">00</span>
                <p>ساعات</p>
            </div>
            <div class="time">
                <span id="minutes2">00</span>
                <p>دقائق</p>
            </div>
            <div class="time">
                <span id="seconds2">00</span>
                <p>ثواني</p>
            </div>
        </div>
        <div class="message">
            <p>الوقت المتبقي</p>
        </div>
    </div>
    <div class="footer">
        <div class="part-logo">
          <div class="logo-footer">
            <img src="/static/images/log.webp" width="80" style="border-radius: 50%;">
            <span><b>Tawjeeh</b> Education</span>
          </div>
          <div class="logo-description">
            <p>Get All References By Fast And Simply</p>
            <p> we are striving to provide the best learning material on <br>technical and non-technical subjects.</p>
            <div class="copyright">
              <p>© Twajeeh 2024 -
                <?php echo date('Y')?>
              </p>
            </div>
          </div>
          <div class="social">
            <i onclick="window.location ='https://www.facebook.com/profile.php?id=61560868892128&mibextid=ZbWKwL' "
              class="fab fa-facebook"></i>
            <i onclick="window.location='https://www.instagram.com/edutawjeeh?igsh=Mnd2Ymhodzc1enE5'"
              class="fab fa-instagram"></i>
            <i onclick="window.location='https://t.me/eduTawjeeh'" class="fab fa-telegram"></i>
            <!-- <i class="fab fa-twitter"></i> -->
            <i onclick="window.location = 'https:\/\/www.youtube.com/@EduTawjeeh'" class="fab fa-youtube"></i>
            <i onclick="document.location.href = 'https:\/\/tiktok.com/@Edutawjeeh'" class="fab fa-tiktok"></i>
            <i onclick="window.location = 'https:\/\/www.x.com/@EduTawjeeh'" class="fab fa-twitter"></i>
          </div>
        </div>
        <div class="classes">
          <h1>الصفوف </h1>
          <a href="/class/الاعدادي.html" class="link" style="color:white">السادس العدادي</a>
      <a href="/class/الابتدائي.html" class="link" style="color:white">الثالث المتوسط</a>
      <a href="/class/الابتدائي.html" class="link" style="color:white">السادس االبتدائي</a>

        </div>
        <div class="contact-us">
          <h1>تواصل </h1>
    
          <a href="mailto:edutawjeeh1@gmail.com" style="color:white" class="link">عبر الايميل</a>
          <a href="https://t.me/ContactTawjeehBot" style="color:white" class="link">عبر التيليجرام</a>
    
        </div>
    
      </div>
      <script>
  // تحديد تواريخ الامتحانات
const examDate1 = new Date(2024, 10, 18, 11, 1, 0);  // 18 نوفمبر 2024 الساعة 11:01
const examDate2 = new Date(2024, 11, 15, 9, 0, 0);   // 15 ديسمبر 2024 الساعة 09:00

// دالة لحساب الوقت المتبقي
function updateCountdown(examDate, daysElement, hoursElement, minutesElement, secondsElement, messageElement) {
    const now = new Date();
    const timeDiff = examDate - now;

    // إذا انتهت الامتحانات
    if (timeDiff <= 0) {
        // إخفاء العد التنازلي
        daysElement.innerText = '00';
        hoursElement.innerText = '00';
        minutesElement.innerText = '00';
        secondsElement.innerText = '00';

        // تغيير النص في الرسالة إلى "الامتحان قد بدأ!"
        if (messageElement) {
            messageElement.innerHTML = "الامتحان قد بدأ!";
        }
        return;
    }

    // حساب الأيام، الساعات، الدقائق والثواني
    const days = Math.floor(timeDiff / (1000 * 60 * 60 * 24));
    const hours = Math.floor((timeDiff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    const minutes = Math.floor((timeDiff % (1000 * 60 * 60)) / (1000 * 60));
    const seconds = Math.floor((timeDiff % (1000 * 60)) / 1000);

    // تحديث القيم في العداد
    daysElement.innerText = days.toString().padStart(2, '0');
    hoursElement.innerText = hours.toString().padStart(2, '0');
    minutesElement.innerText = minutes.toString().padStart(2, '0');
    secondsElement.innerText = seconds.toString().padStart(2, '0');

    // تحديث الرسالة لعرض الوقت المتبقي
    if (messageElement) {
        messageElement.innerHTML = "انتهى الوقت . بدأت الامتحانات الوزارية , بالتوفيق لطلبتنا الأعزاء";
    } return
}

// تحديث العدادات بشكل دوري
setInterval(function() {
    updateCountdown(
        examDate1, 
        document.getElementById("days1"), 
        document.getElementById("hours1"), 
        document.getElementById("minutes1"), 
        document.getElementById("seconds1"),
        document.getElementById("message1") // تمرير العنصر الذي يحتوي على الرسالة
    );

    updateCountdown(
        examDate2, 
        document.getElementById("days2"), 
        document.getElementById("hours2"), 
        document.getElementById("minutes2"), 
        document.getElementById("seconds2"),
        document.getElementById("message2") // تمرير العنصر الذي يحتوي على الرسالة
    );
}, 1000);

</script>

</body>
</html>
