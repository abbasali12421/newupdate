<?php
// Need To Be Configure
header('Content-Type: text/html; charset=UTF-8');
require_once 'config.php'; // Database connection

// Get the book ID from the URL parameter
$book_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

// Fetch book data from the database
$query = $conn->prepare("SELECT * FROM books WHERE id = ?");
$query->bind_param("i", $book_id);
$query->execute();
$result = $query->get_result();
$book = $result->fetch_assoc();

if (!$book) {
    echo "Book not found.";
    exit;
}
?>

?>

<!DOCTYPE html>
<html lang="ar">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>صفحة تحميل الملف</title>
  <link rel="stylesheet" href="style/book.css">
  
</head>
<body>

  <div class="content">
    <div class="download-box">
      <div class="book-image">
        <img src="https://www.noor-book.com/publice/covers_cache_webp/1/5/7/d/76fbc6dd1557d2f0f1b5ab2dd787007e.jpg.webp" alt="صورة الكتاب">
        <div class="book-title-under-image">
          <h2>القرآن الكريم</h2>
        </div>
      </div>

      <div class="book-info">
        <h1>القرآن الكريم</h1>
        <h3>تحميل كتاب القرآن الكريم</h3>
        <p><strong>المادة:</strong>الوصف الخاص بالكتاب القصير  <span></span></p>
        <p><strong>المرحلة الدراسية:</strong> الصف الدراسي <span></span></p>
        <p><strong>الوصف:</strong>الوصف الخاص بالكتاب القصير  <span></span></p>
        <p><strong>إعداد:</strong> اعداد منصة او استاذ<span></span></p>
        <p><strong>عدد الصفحات:</strong>عدد صفحات الملف <span></span></p>
        <p><strong>حجم الملف:</strong>  حجم الملف <span></span></p>
        <p><strong>نوع الملف:</strong> وورد او بي دي اف او ايكسل<span></span></p>
        <p><strong>تاريخ الأصدار</strong> سنة اصدار الملف من قبل الجهة<span></span></p>

        <div class="buttons">
            <button class="copy-button" onclick="copyLink()">نسخ الرابط</button> <!-- زر نسخ الرابط -->
          <button class="share-button" onclick="showModal()">مشاركة</button>
          <button class="download-button">تحميل</button>

        </div>
      </div>
    </div>

    <div class="description-box">
      <h2 class="title-description-bx" >الوصف الكامل للكتاب</h2>
      <p>يحتوي هذا الكتاب على تفسير القرآن الكريم...</p>
    </div>
  </div>

  <!-- النافذة المنبثقة -->
  <div class="modal" id="shareModal">
    <div class="modal-content">
      <h3>اختر المنصة التي تريد أن تشارك بها الصفحة</h3>
      <button onclick="shareOnTelegram()">تليكرام <img src="https://pngimg.com/uploads/telegram/telegram_PNG12.png" class="social-icon" alt="تليكرام"></button>
      <button onclick="shareOnWhatsApp()">واتساب <img src="https://upload.wikimedia.org/wikipedia/commons/6/6b/WhatsApp.svg" class="social-icon" alt="واتساب"></button>
      <button onclick="shareOnInstagram()">إنستغرام <img src="https://upload.wikimedia.org/wikipedia/commons/a/a5/Instagram_icon.png" class="social-icon" alt="إنستغرام"></button>
      <button onclick="shareOnFacebook()">فيسبوك <img src="https://upload.wikimedia.org/wikipedia/commons/5/51/Facebook_f_logo_%282019%29.svg" class="social-icon" alt="فيسبوك"></button>
      <button class="copy-button" onclick="copyLink()">نسخ الرابط</button> <!-- زر نسخ الرابط -->
      <button onclick="closeModal()">إغلاق</button>
    </div>
  </div>

  <script>
    function showModal() {
      document.getElementById("shareModal").style.display = "block"; // إظهار النافذة
    }

    function closeModal() {
      document.getElementById("shareModal").style.display = "none"; // إغلاق النافذة
    }

    function shareOnTelegram() {
      const url = window.location.href;
      const telegramUrl = `https://t.me/share/url?url=${encodeURIComponent(url)}`;
      window.open(telegramUrl, '_blank');
      closeModal(); // إغلاق النافذة بعد المشاركة
    }

    function shareOnWhatsApp() {
      const url = window.location.href;
      const whatsappUrl = `https://api.whatsapp.com/send?text=${encodeURIComponent(url)}`;
      window.open(whatsappUrl, '_blank');
      closeModal(); // إغلاق النافذة بعد المشاركة
    }

    function shareOnInstagram() {
      alert('يمكنك مشاركة الرابط في إنستغرام.');
      closeModal(); // إغلاق النافذة بعد الإشعار
    }

    function shareOnFacebook() {
      const url = window.location.href;
      const facebookUrl = `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(url)}`;
      window.open(facebookUrl, '_blank');
      closeModal(); // إغلاق النافذة بعد المشاركة
    }

    function copyLink() {
      const url = window.location.href;
      navigator.clipboard.writeText(url).then(() => {
        alert('تم نسخ الرابط بنجاح!');
      }, () => {
        alert('فشل نسخ الرابط.');
      });
    }
  </script>

</body>
</html>
