function submitForm() {
    // Find the selected radio button
    const selectedRadio = document.querySelector('input[type="radio"]:checked');
    
    if (selectedRadio) {
        // Collect data from data attributes of the selected radio button
        const value1 = selectedRadio.dataset.value1;
        const name1 = selectedRadio.dataset.name1;
        const value2 = selectedRadio.dataset.value2;
        const name2 = selectedRadio.dataset.name2;
        const value3 = selectedRadio.dataset.value3;
        const name3 = selectedRadio.dataset.name3;

        // Prepare the data payload
        const payload = {
            [name1]: value1,
            [name2]: value2,
            [name3]: value3
        };

        // Send data to filter.php
        fetch('filter.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(payload)
        })
        .then(response => response.json())
        .then(data => {
            // Insert returned HTML into the main-body container
            document.querySelector('.main-body').innerHTML = data.html;
        })
        .catch(error => console.error('Error:', error));
    } else {
        console.log('No radio button selected.');
    }
}
