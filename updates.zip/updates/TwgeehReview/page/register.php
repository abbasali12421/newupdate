<?php
session_start();

// Include the database connection file
include '../config.php';

// Initialize error message variable
if (!isset($_SESSION['error_message'])) {
    $_SESSION['error_message'] = '';
}

if ($_SERVER['REQUEST_METHOD'] == "POST") {
    $fname = $_POST['fname'];
    $lname = $_POST['lname'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $repassword = $_POST['repassword'];
    $city = $_POST['city'];

    // Validate city input
    $valid_cities = array('بغداد', 'البصرة', 'نينوى', 'الأنبار', 'النجف', 'كربلاء', 'واسط', 'ديالى', 'ذي قار', 'ميسان', 'المثنى', 'بابل', 'صلاح الدين', 'القادسية (الديوانية)', 'كركوك', 'اربيل', 'دهوك', 'السليمانية','None');
    if (!in_array($city, $valid_cities)) {
        echo '<script>alert("Invalid city selected.")</script>';
        exit;
    }

    // Hash password using bcrypt
    $hashed_password = password_hash($password, PASSWORD_BCRYPT);

    // Use prepared statement to prevent SQL injection
    $sql = "SELECT * FROM `reg` WHERE email = ?";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "s", $email);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    if ($result) {
        $num = mysqli_num_rows($result);
        if ($num > 0) {
            $_SESSION['error_message'] = 'User already exists.';
        } else {
            $sql = "INSERT INTO `reg` (fname, lname, email, password, city) VALUES (?, ?, ?, ?, ?)";
            $stmt = mysqli_prepare($conn, $sql);
            mysqli_stmt_bind_param($stmt, "sssss", $fname, $lname, $email, $hashed_password, $city);
            mysqli_stmt_execute($stmt);

            if (mysqli_stmt_affected_rows($stmt) > 0) {
                $_SESSION['success_message'] = 'Registration successful.';
                header('location: login.php');
                exit;
            } else {
                die(mysqli_error($conn));
            }
        }
    }
}

// Input validation
$fname = filter_input(INPUT_POST, 'fname', FILTER_SANITIZE_STRING);
$lname = filter_input(INPUT_POST, 'lname', FILTER_SANITIZE_STRING);
$email = filter_input(INPUT_POST, 'email', FILTER_VALIDATE_EMAIL);
$password = filter_input(INPUT_POST, 'password', FILTER_SANITIZE_STRING);
$repassword = filter_input(INPUT_POST, 'repassword', FILTER_SANITIZE_STRING);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css" integrity="sha512-Kc323vGBEqzTmouAECnVceyQqyqdsSiqLQISBL29aUW4U/M7pSPA/gEUZQqv1cwx4OnYxTxve5UMg5GT6L4JJg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="/style/register.css">
    <title>Create Account Now</title>
</head>
<body>
<?php if (!empty($_SESSION['error_message'])) { ?>
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <strong><?php echo htmlspecialchars($_SESSION['error_message']); ?></strong>
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div>
    <?php
    // Clear the error message after displaying it
    $_SESSION['error_message'] = '';
    ?>
<?php } ?>

<?php if (!empty($_SESSION['success_message'])) { ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <strong><?php echo htmlspecialchars($_SESSION['success_message']); ?></strong>
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div>
    <?php
    // Clear the success message after displaying it
    $_SESSION['success_message'] = '';
    ?>
<?php } ?>

      <div class="login-panel">
        <div class="container">
            <div class="form-controls">
                <!-- create Inputs -->
                 <div class="title">
                    <img src="/static/icons/Book.webp" width="20" alt="error">
                    <span>Tawjeeh</span>
                 </div>
                 <div class="description">
                    <p>
                        Welcome Back , Create Account <br> And Shop Now.
                    </p>
                 </div>
                 <!-- #region Comment HTML-->
                 <!-- <div class="login-btns">
                    <button class="btn btn-google"><i class="fab fa-google"></i><span>Login With Google </span></button>
                    <button class="btn btn-facebook"><i class="fab fa-facebook-f"></i><span>Login With Facebook </span></button>
                 </div> -->
                 <!-- <div class="move-line">
                     <span class="or-line-left"></span>
                     <p class="or-line">OR</p>
                     <span class="or-line-right"></span>
                 </div> -->
                 <!-- #endregion -->
                 <form action="register.php" method="post">
                    <div class="form-inputs">
                        <input required type="text" name="fname" id="fname">
                        <label for="fname">First Name</label>
                    </div>
                    <div class="form-inputs">
                        <input required type="text" name="lname" id="lname">
                        <label for="lname">Last Name</label>
                    </div>
                    <div class="form-inputs">
                        <input required type="text" name="email" id="email">
                        <label for="email">Email Address</label>
                    </div>
                    <div class="form-inputs">
                        <input required type="password" name="password" id="password">
                        <label for="password">Password</label>
                    </div>
                    <div class="form-inputs">
                        <input required type="password" name="repassword" id="repassword">
                        <label for="repassword">repeat password</label>
                    </div>
             
                     <select class="cites-selector arabic select" name="city">
                        <option class="arabic" value="بغداد">بغداد</option>
                        <option class="arabic" value="البصرة">البصرة</option>
                        <option class="arabic" value="نينوى">نينوى</option>
                        <option class="arabic" value="الأنبار">الأنبار</option>
                        <option class="arabic" value="النجف">النجف</option>
                        <option class="arabic" value="كربلاء">كربلاء</option>
                        <option class="arabic" value="واسط">واسط</option>
                        <option class="arabic" value="ديالى">ديالى</option>
                        <option class="arabic" value="ذي قار">ذي قار</option>
                        <option class="arabic" value="ميسان">ميسان</option>
                        <option class="arabic" value="المثنى">المثنى</option>
                        <option class="arabic" value="بابل">بابل</option>
                        <option class="arabic" value="صلاح الدين">صلاح الدين</option>
                        <option class="arabic" value="القادسية (الديوانية)">القادسية (الديوانية)</option>
                        <option class="arabic" value="كركوك">كركوك</option>
                        <optgroup class="arabic" label="محافظات اقليم كردستان">
                          <option class="arabic" value="اربيل">اربيل</option>
                          <option class="arabic" value="دهوك">دهوك</option>
                          <option class="arabic" value="السليمانية">السليمانية</option>
                        </optgroup>
                        </select>
                      <select name="lvl" class="cites-selector arabic select">
                                <optgroup class="arabic" label="المرحلة الاعدادية">
                                <option class="arabic" value="pre1">الرابع العلمي</option>
                                <option class="arabic" value="pre2">الرابع الادبي</option>
                                <option class="arabic" value="pre3">الخامس العلمي</option>
                                <option class="arabic" value="pre4">الخامس الادبي</option>
                                <option class="arabic" value="pre5">السادس العلمي</option>
                                <option class="arabic" value="pre6">السادس الادبي</option>
                                </optgroup>
                                <optgroup class="arabic" label="المرحلة المتوسطة">
                                <option class="arabic" value="mid1">الأول المتوسط</option>
                                <option class="arabic" value="mid2">الثاني المتوسط</option>
                                <option class="arabic" value="mid3">الثالث المتوسط</option>
                                </optgroup>
                                <optgroup class="arabic" label="المرحلة الابتدائية">
                                <option class="arabic" value="f1">الأول الابتدائي</option>
                                <option class="arabic" value="f2">الثاني الابتدائي</option>
                                <option class="arabic" value="f3">الثالث الابتدائي</option>   
                                <option class="arabic" value="f4">الرابع الابتدائي</option>
                                <option class="arabic" value="f5">الخامس الابتدائي</option>
                                <option class="arabic" value="f6">السادس الابتدائي</option>
                                </optgroup>

                    
                      </select>
                      <div class="rem">
                        <div class="forms-check dir">
                         <input type="checkbox" onclick="Hide()" name="city" id="check" value="None">
                         <label  for="check" dir="rtl">انا لست من العراق</label>
                        </div>
                        
                      </div>
                      
                     <button id="clickme" type="submit" name="submit" style="display: none;"></button>
                      
                    </form>
                    <div class="form-buttons">
                     <button class="btn-submit" onclick="clickme()">Create Account</button>
                    <!-- <a href="login.html"><button style="color:black;background: transparent;border: 2px solid rgba(0, 0, 0, 0.397);">Sign in</button></a> -->
                 </div>
                 <div class="social-buttons-custom mt-5">
                   
                        <Button class="circle-btn facebook"><i class="fab fa-facebook-f"></i> Facebook Account</Button>
                        <Button class="circle-btn google"><i class="fab fa-google"></i> Google Account</Button>
                       
                    </div>
                    
               
                 
    
            </div>
        </div>
        <div class="desgin-panel">
            <div class="btn-return">
                <button onclick="window.location.href='/../index.php'" class="return"><i class="fa-solid fa-angle-left"></i> Back</button>
            </div>
            <div class="words">
                <h1>Welcome My Brother</h1>
                <h1>You Have Account On Another Platform ?</h1>
                <br><br>
                <p>Sign in By Google Or Facebook<br> please click on google or facebook</p>
                <br><br>
                <div class="btns">
                    <div class="content-btn">
                        <Button class="btn-custom"><i class="fab fa-facebook-f"></i></Button>
                        <br>
                        <p class="content-btn-title">Facebook</p>
                    </div>
                    <div class="content-btn">
                        <Button><i class="fab fa-google"></i></Button>
                        <br>
                        <p class="content-btn-title ml-2">Google</p>
                    </div>
                    
                </div>
            </div>
        </div>
    </div>
    <script src="/js/submit.js"></script>
</body>
</html>