<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css" integrity="sha512-Kc323vGBEqzTmouAECnVceyQqyqdsSiqLQISBL29aUW4U/M7pSPA/gEUZQqv1cwx4OnYxTxve5UMg5GT6L4JJg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="/style/login.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <style>
        .popup{
            position: absolute;
            width: 500px;
            height: 300px;
            background-color: white;
            color: black;
            border: 1px solid rgba(0, 0, 0, 0.26);
            padding: 15px;
            z-index: 55555;
            padding-top: 20px;
            border-radius: 6px;
            left: 50%;
            top: -500px;
            transform: translateX(-50%);
        
        }
        
        @media screen and (max-width:900px) {
            .popup{
                width: 400px;
            }
            
        }
    </style>
    <title>Tawjeeh - Login Now</title>
</head>
<body>
    <div class="popup">
        <div class="close" style="direction: rtl;cursor: pointer;"><i class="fas fa-close"></i></div>
        <h1>Set Active Code</h1>
        <p>we are send on your email address please get code</p>
        <p>from email address and put here please to reset password</p>
        <form action="" method="post">
            <div style="margin-top: 30px;" class="form-inputs">
                <input required type="number" name="code" id="code">
                <label for="code">Enter Code 4 Number from your Email</label>
            </div>
            <div class="form-buttons">
                <button type="submit">send code</button>
              
             </div>
        </form>
    </div>
    <div class="login-panel">
        <div class="container">
            <div class="form-controls">
                <!-- create Inputs -->
                 <div class="title">
                    <img src="/static/icons/Book.webp" width="20" alt="error">
                    <span>Tawjeeh</span>
                 </div>
                 <div class="description">
                    <p>
                        Ooh you are forget your password , Please enter your  <br> email account
                    </p>
                 </div>
               
                 
                
                    <div style="margin-top: 30px;" class="form-inputs">
                        <input required type="text" name="mail" id="email">
                        <label for="email">Email Address</label>
                    </div>
                   
                   
                    <div class="form-buttons" style="margin-top: 50px;">
                        <button class="submit">send code</button>
                      
                     </div>
               
                 
                 <div style="margin-top: 50px;">
                    <br><br>
                    <p>By Signing uo , you agree to Tawjeeh's <br> <a style="text-decoration: underline;" href="#">Terms and Conditions</a> & <a style="text-decoration: underline;" href="#">Privacy Policy</a></p>
                 </div>
                 
    
            </div>
        </div>
        <div class="desgin-panel">
            <div class="btn-return">
                <!-- change Page Name -->
                <button class="return" onclick="window.location.href='/../index.htm'"><i class="fa-solid fa-angle-left"></i> Back</button>
            </div>
            <div class="words">
                <h1>Welcome My Brother</h1>
                <h1>You Are Not Know About service us ?</h1>
                <br><br>
                <p>Go To Home Page and Read About My Services, if you want that<br> please click on home</p>
                <br><br>
                <a href="../index.htm#service"><Button><i class="fas fa-home"></i></Button></a>
            </div>
        </div>
    </div>
    <script src="/js/submit.js"></script>
    <script>
        $(".submit").click(function(){
            var send = {
                "email":$("#email").val()
            }
            if(send.email == ""){
                alert("empty")
            }else{
                fetch("process.php",{
                method:"POST",
                headers:{
                    "Content-Type":"x-www-form-urlencoded"
                },
                body:"email=" + send.email
            })
            $(".popup").animate({
                "top":"50px"
            })
            $(".login-panel").css({
                "pointer-events":"none",
                "user-select":"none"
            }).animate({"opacity":"0.3"})
            }
        })
        $(".close").click(function(){
            $(".popup").animate({
                "top":"-5555px"
            })
            $(".login-panel").css({
                "pointer-events":"all",
                "user-select":"all"
            }).animate({"opacity":"1"})
        })
    </script>
    
</body>
</html>