<?php
require_once 'config.php';

if (isset($_POST['search'])) {
    $search = $conn->real_escape_string($_POST['search']);
    $query = "SELECT * FROM posts WHERE title LIKE '%$search%' ORDER BY date DESC";
    $result = $conn->query($query);

    if ($result->num_rows > 0) {
        while ($post = $result->fetch_assoc()) {
            echo '<div class="post">
                    <div class="image-post">
                        <img class="img" src="/admin/uploads/'.$post['img'].'" />
                    </div>
                    <div class="post-details p-3 mx-3">
                        <h3><a class="nav-link" href="/blog/post.php?id='.$post['id'].'">'.$post['title'].'</a></h3>
                        <div class="author">
                            <span><i class="fas fa-user"></i> admin</span>
                            <span><i class="fas fa-clock"></i> '.$post['date'].'</span>
                        </div>
                        <p class="post-description">'.substr($post['content'], 0, 50).'...</p>
                    </div>
                </div>';
        }
    } else {
        echo "No posts found.";
    }
}
?>
