class App {
    static TemplateHide() {
        for (let i = 0; i < $("li").length; i++) {
            $(".admin-content-panel").eq(i).css({"display":"none"})
        }
    }
}
$(document).ready(function () {
    // publish book
    $("#btn-publish").click(function () {
        var bookdetails = $(".textbox").val();
        var hiddenDetailsInput = $("#book-details").val(bookdetails);
        var url = $("#url-send").val($("#url").val())
        $("#submit").click();

    })
    App.TemplateHide();
    $(".admin-content-panel").eq(0).show("fast")
    $("li").click(function () {
        App.TemplateHide();
        $(".admin-content-panel").eq($(this).index()).css({"display":"block"})
    });

});
var simplemde = new SimpleMDE({
    element: $("#editor")[0],
    placeholder: "Enter Your Post Content.....",
    promptURLs: true,
    renderingConfig: {
        codeSyntaxHighlighting: true,
    },
    shortcuts: {
        drawTable: "Cmd-Alt-T"
    },
    showIcons: ["code", "table", "horizontal-rule", "heading-bigger", "heading-smaller", "side-by-side", "strikethrough"]

});
class Ajax {
    constructor(phpscript, formData) {
        fetch(phpscript, {
            method: "POST",
            body: formData
        })
            .then(response => response.json())
            .then(data => console.log(data))
            .catch(error => console.error('Error:', error));
    }
}

$(".post-send").click(function () {
    var markdownContent = simplemde.value();
    var htmlContent = simplemde.options.previewRender(markdownContent);

    // Create a new FormData object
    var formData = new FormData();
    formData.append("post-title", $("#post-title").val());
    formData.append("post-author", $("#post-author").val());
    formData.append("post-date", $("#post-date").val());
    formData.append("post-content", htmlContent);
    formData.append("post-markdown", markdownContent);

    // Append the selected file
    var fileInput = document.getElementById('post-img');
    var file = fileInput.files[0];
    if (file) {
        formData.append("post-img", file);
    }

    // Send the FormData object using Ajax
    var ajax = new Ajax("process.php", formData);
});
$(document).ready(function () {
    $("#freeclick").click(function () {
        $(this).addClass("active");
        $("#free").attr("name", "free");
        $("#free").attr("value", "free");
        $("#buyclick").removeClass("active")



    })
    $("#buyclick").click(function () {
        $(this).addClass("active");
        $("#free").attr("name", "buy");
        $("#free").attr("value", "buy");
        $("#freeclick").removeClass("active");


    })
})
// switch between dark mode and light mode
$(".darkmode-btn").click(function(){
    $(".container").toggleClass("lightmode")
    $(".card").toggleClass("lightmode-card")
    $(".input-form,.select-class").toggleClass("lightmode-input")
    $(".text-black").toggleClass("lightmode-text")
    $(".edit-post").toggleClass("lightmode-edit")
    $(".menu-left").toggleClass("lightmode-menu-left")
    $(".item").toggleClass("lightmode-list")
    $(".testing").toggleClass("test")
   
    
})