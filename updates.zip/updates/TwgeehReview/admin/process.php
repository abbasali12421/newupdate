<?php
include('config.php');

$postTitle = $_POST['post-title'];
$postAuthor = $_POST['post-author'];
$postDate = $_POST['post-date'];
$postContent = $_POST['post-content'];

// Get the uploaded image
$postImg = $_FILES['post-img'];

// Check if the image is uploaded
if ($postImg['size'] > 0) {
    // Generate a unique filename for the image
    $filename = uniqid() . '.' . pathinfo($postImg['name'], PATHINFO_EXTENSION);

    // Move the uploaded image to the /uploads directory
    $targetPath = __DIR__ . '/uploads/' . $filename;
    if (move_uploaded_file($postImg['tmp_name'], $targetPath)) {
        $imgData = $filename;
    } else {
        $imgData = null;
        echo 'Error uploading image';
    }
} else {
    $imgData = null;
}

// Process the data and insert it into your database
$query = "INSERT INTO posts (title, author, date, content, img) VALUES (?, ?, ?, ?, ?)";
$stmt = $conn->prepare($query);
$stmt->bind_param("sssss", $postTitle, $postAuthor, $postDate, $postContent, $imgData);
$stmt->execute();
$stmt->close();
$conn->close();

// Return a response to the client
echo "<h1>Post created successfully!</h1>";
?>