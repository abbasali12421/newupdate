<?php
$host = 'localhost';
$username = 'root';
$password = '';
$namedb = 'form';

$conn = new mysqli($host, $username, $password, $namedb);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
