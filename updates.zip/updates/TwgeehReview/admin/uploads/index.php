<?php
echo "hellow omar";
?>