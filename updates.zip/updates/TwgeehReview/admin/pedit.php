<?php
// Include the database connection
include('config.php');

// Check if the form was submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    // Get the form inputs
    $postId = isset($_POST['post-id']) ? $_POST['post-id'] : '';  // Get post ID to update
    $postTitle = isset($_POST['post-title']) ? $_POST['post-title'] : '';
    $postAuthor = isset($_POST['post-author']) ? $_POST['post-author'] : '';
    $postDate = isset($_POST['post-date']) ? $_POST['post-date'] : '';
    $postContent = isset($_POST['post-content']) ? $_POST['post-content'] : '';

    // Validate post ID
    if (!is_numeric($postId)) {
        echo json_encode(['status' => 'error', 'message' => 'Invalid Post ID']);
        exit;
    }

    // Handle file upload (if a new file is uploaded)
    $postImage = null;
    if (isset($_FILES['post-img']) && $_FILES['post-img']['error'] == 0) {
        $imageName = $_FILES['post-img']['name'];
        $imageTmpName = $_FILES['post-img']['tmp_name'];
        $imageSize = $_FILES['post-img']['size'];
        $imageError = $_FILES['post-img']['error'];
        $imageType = $_FILES['post-img']['type'];

        // Validate the file type (image only)
        $allowedTypes = ['image/jpeg', 'image/png', 'image/gif'];
        if (in_array($imageType, $allowedTypes)) {
            $targetDir = "uploads/";  // Folder to save images
            $targetFile = $targetDir . basename($imageName);

            // Move the uploaded file to the target directory
            if (move_uploaded_file($imageTmpName, $targetFile)) {
                $postImage = $targetFile;
            } else {
                echo json_encode(['status' => 'error', 'message' => 'File upload failed.']);
                exit;
            }
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Invalid file type.']);
            exit;
        }
    }

    // Prepare the update SQL query
    $updateQuery = "UPDATE posts SET title = ?, author = ?, date = ?, content = ?";

    // If a new image is uploaded, include it in the update query
    if ($postImage) {
        $updateQuery .= ", img = ?";
    }

    // Append the condition to update the specific post based on ID
    $updateQuery .= " WHERE id = ?";

    // Prepare the statement
    $stmt = $conn->prepare($updateQuery);

    // Log the query for debugging
    error_log("Update Query: " . $updateQuery);

    // If an image was uploaded, bind parameters accordingly
    if ($postImage) {
        $stmt->bind_param("ssssss", $postTitle, $postAuthor, $postDate, $postContent, $postImage, $postId);
    } else {
        $stmt->bind_param("sssss", $postTitle, $postAuthor, $postDate, $postContent, $postId);
    }

    // Execute the statement
    if ($stmt->execute()) {
        echo json_encode(['status' => 'success', 'message' => 'Post updated successfully!']);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Failed to update post.', 'error' => $stmt->error]);
    }

    // Close the statement
    $stmt->close();
    $conn->close();
}
?>
